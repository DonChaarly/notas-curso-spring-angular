export class Mensaje {
  texto: string = '';
  fecha: Date;
  username: string;
  tipo: string;
  color: string;
}
